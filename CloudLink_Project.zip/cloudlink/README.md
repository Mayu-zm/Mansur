# CloudLink
URL shortener with click statistics. Cloud Builders: Tlektes Yelnur (202699544), Anefiyayeva Akerke (202699542), Malik Mansur (202699543).

## Status
Prepared implementation for the supplied Docker & Microservices proposal. Application unit/API tests passed in the preparation environment. Docker was unavailable there, so container build, PostgreSQL integration, scaling, restart behaviour and live benchmark results must be verified on the demo laptop. No performance results, deployment evidence, GitHub repository or individual contributions are claimed as completed.

## Start on macOS
Install and open Docker Desktop, wait for the engine to run. Install Python 3 if `python3 --version` is unavailable. In Terminal, change into this folder, then run:

```bash
python3 scripts/manage.py doctor
python3 scripts/manage.py up
python3 scripts/manage.py smoke
```
Open http://localhost:8080. First start downloads images and packages, so do this before class with internet access. Docker Desktop may need several minutes. Keep the same extracted project folder for subsequent runs.

## Demonstrate

```bash
python3 scripts/manage.py scale --replicas 1
python3 scripts/manage.py instances
python3 scripts/manage.py scale --replicas 3
python3 scripts/manage.py instances
python3 scripts/manage.py compare --requests 600 --concurrency 20
python3 scripts/manage.py failure --requests 300 --concurrency 10
python3 scripts/manage.py persistence
```
The comparison runs three trials with identical load per replica count. It benchmarks GET /api/instance, a lightweight routing endpoint. Do not present its results as redirect/database throughput. For redirect load, create a link first and repeat `bench --path /r/ACTUAL_CODE --label redirects-1` at 1 and 3 replicas, using matching parameters. The tool does not follow the redirect destination.

The failure test stops one of three Link API containers, leaves the old Nginx upstream in place, sends safe GET requests and explicitly restarts the same container in a `finally` block. Nginx can retry safe instance requests across replicas. Create and redirect requests have proxy retries disabled to reduce replayed writes. They can briefly fail during an outage. A click is a committed redirect request, not proof that the external page loaded or a unique person visited.

The persistence test creates a fresh link, records 3 clicks, runs `docker compose down` WITHOUT `-v`, recreates containers and compares the saved URL and counter. It interrupts the local demo briefly. Never add `-v` unless you deliberately want to delete all saved links.

## Architecture
Browser -> Nginx -> Link API replicas / Statistics API -> shared PostgreSQL.
- Nginx serves HTML/CSS/JS and routes requests. Only 127.0.0.1:8080 is published.
- Link API creates random 8-character codes and performs redirects with an atomic database increment.
- Statistics API reads the latest 100 records and per-link counts.
- PostgreSQL lives only on the internal `data` network and uses the named `pgdata` volume.
- Link API and Statistics API join `edge` and `data`. Nginx joins only `edge`.
- After scaling, the controller inspects replica IPs, writes Nginx upstreams atomically, checks configuration and reloads Nginx. It needs Docker access on the host; containers do not mount the Docker socket.

Source architecture diagram: docs/architecture.mmd. Detailed explanation and speaking: docs/DEFENSE_GUIDE_RU.md and docs/SPEAKING_EN.md.

## API
| Method | Route | Behaviour |
|---|---|---|
| POST | /api/links | JSON {"url":"https://example.com"}, returns 201 and short_path |
| GET | /r/CODE | Atomically increment and return 302 Location |
| HEAD | /r/CODE | Return destination headers without a click increment |
| GET | /api/stats | Latest 100 links and counts |
| GET | /api/stats/CODE | One record or 404 |
| GET | /api/instance | Replica identity for load-balancing verification |
| GET | /healthz | Per-service process liveness, internal only |
| GET | /readyz | Per-service database readiness, internal only |

## Tests
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
python -m pytest tests -q
```
Unit/API tests inject an in-memory store; SQL contract tests inspect parameter binding and atomic UPDATE statements. They do not replace real PostgreSQL or Docker tests. The `smoke`, `failure` and `persistence` commands provide real-stack checks after startup. Use `docker compose logs --tail 80` to diagnose a failure. Do not claim a scenario passed without observing its output.

## Operations
`python3 scripts/manage.py status` lists containers. `docker compose logs -f --tail 50` streams logs. `docker stats --no-stream` shows host resource use. `python3 scripts/manage.py down` stops and removes containers while retaining the volume. `python3 scripts/manage.py up` rebuilds, starts and refreshes routing. Use the controller after recreating any application containers to avoid stale Nginx IPs.

Do not edit POSTGRES_PASSWORD after initializing the volume without changing the actual database role password. If port 8080 is busy, edit APP_PORT in .env and run `up`; use the printed URL. Changing directory/project names changes Compose context: use this same folder and fixed `name: cloudlink` throughout.

## Scope and limitations
This is a local single-host container prototype demonstrating cloud-native concepts, as allowed by the supplied proposal. It does not provision AWS/OpenStack or provide a managed cloud service. Scaling is manual and automated through a script, not automatic demand-based scaling. Proxy, database and host are single points of failure. Docker restart policies respond to container exits; an unhealthy status alone does not restart a container, and an intentional stop needs an explicit start. Shared database ownership couples the services.

Security measures: HTTP/HTTPS scheme validation, rejection of credentials and control characters in URLs, SQL parameters, bounded request size, non-root Python containers, database network isolation, loopback-only publication, browser textContent rendering, basic security headers and .env excluded from git. External URLs are stored and redirected, not fetched server-side. This still intentionally allows redirects to arbitrary destinations and has no authentication, abuse prevention, quotas, TLS, backup policy or unique-visitor tracking. A public deployment needs those controls.

## Repository and contributions
The proposal lists https://github.com/yelnurtlektes/cloudlink as a PLANNED repository. This package does not create or publish it. Guidance says no GitHub updates after November 18, 2026 at 23:55. Obtain instructor guidance on late submission before pushing this new implementation. Preserve real authorship and actual commit dates. The proposed roles are a rehearsal plan, not evidence of work performed by individual members.

## Primary references
- https://docs.docker.com/reference/compose-file/services/
- https://docs.docker.com/reference/cli/docker/compose/up/
- https://docs.docker.com/engine/containers/start-containers-automatically/
- https://docs.docker.com/compose/how-tos/startup-order/
- https://nginx.org/en/docs/http/ngx_http_upstream_module.html
- https://nginx.org/en/docs/http/ngx_http_proxy_module.html
