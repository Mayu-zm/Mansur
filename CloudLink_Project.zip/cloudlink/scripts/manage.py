#!/usr/bin/env python3
"""Portable macOS/Linux Docker control and verification. Standard library only."""
import argparse
import collections
import concurrent.futures
import json
import math
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)

def run(*args, capture=False):
    result = subprocess.run(args, check=True, text=True, stdout=subprocess.PIPE if capture else None)
    return result.stdout.strip() if capture else None

def dc(*args, capture=False):
    return run('docker', 'compose', *args, capture=capture)

def init():
    env = ROOT / '.env'
    if not env.exists():
        env.write_text('POSTGRES_USER=cloudlink\nPOSTGRES_DB=cloudlink\nPOSTGRES_PASSWORD=' + secrets.token_hex(24) + '\nAPP_PORT=8080\n')
        env.chmod(0o600)
        print('Created .env with a random password. Keep this file private.')
    conf = ROOT / 'nginx/upstreams.conf'
    if not conf.exists():
        shutil.copyfile(ROOT / 'nginx/upstreams.example.conf', conf)

def base_url():
    port='8080'
    for line in (ROOT/'.env').read_text().splitlines():
        if line.startswith('APP_PORT='): port=line.split('=',1)[1]
    return 'http://localhost:' + port

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl): return None
OPENER = urllib.request.build_opener(NoRedirect)

def request(path, method='GET', data=None):
    req=urllib.request.Request(base_url()+path, method=method,
        data=json.dumps(data).encode() if data is not None else None,
        headers={'Content-Type':'application/json'})
    try:
        response=OPENER.open(req, timeout=12)
    except urllib.error.HTTPError as error:
        response=error
    with response:
        body=response.read()
        try: result=json.loads(body)
        except (ValueError, UnicodeDecodeError): result={}
        return response.status, dict(response.headers), result

def require(condition, message):
    if not condition: raise RuntimeError(message)

def inspect(container):
    return json.loads(run('docker','inspect',container,capture=True))[0]

def ids(service): return dc('ps','-q',service,capture=True).split()

def refresh_proxy():
    # Inspect only the edge network shared with Nginx. Database has no edge address.
    def address(container):
        return inspect(container)['NetworkSettings']['Networks']['cloudlink_edge']['IPAddress']
    links=ids('link_api'); stats=ids('stats_api')
    require(links and stats, 'Application containers must be running')
    text='upstream links {\n zone links 64k;\n'
    text+=''.join(' server '+address(c)+':8000 max_fails=1 fail_timeout=5s;\n' for c in links)
    text+='}\nupstream statistics {\n server '+address(stats[0])+':8000;\n}\n'
    path=ROOT/'nginx/upstreams.conf'
    old=path.read_text()
    temp=path.with_suffix('.tmp'); temp.write_text(text); temp.replace(path)
    try:
        dc('exec','-T','proxy','nginx','-t')
        dc('exec','-T','proxy','nginx','-s','reload')
    except Exception:
        path.write_text(old)
        raise
    print('Nginx upstreams refreshed for',len(links),'Link API replicas')

def up(replicas):
    init()
    # Restore DNS bootstrap before starting a proxy whose old IPs may be stale.
    shutil.copyfile(ROOT/'nginx/upstreams.example.conf', ROOT/'nginx/upstreams.conf')
    dc('up','-d','--build','--wait','--wait-timeout','180','--scale','link_api='+str(replicas))
    refresh_proxy()
    print('Open',base_url())

def scale(replicas):
    dc('up','-d','--wait','--wait-timeout','120','--scale','link_api='+str(replicas),'link_api')
    refresh_proxy()

def distribution(n=30):
    counts=collections.Counter()
    for _ in range(n):
        status,_,body=request('/api/instance')
        counts[body.get('instance','HTTP_'+str(status))]+=1
    print(json.dumps(dict(counts),indent=2)); return counts

def smoke():
    s,_,link=request('/api/links','POST',{'url':'https://example.com/cloudlink-demo'})
    require(s==201,'Create failed: '+str(s)); code=link['code']
    for _ in range(3):
        s,h,_=request('/r/'+code)
        require(s==302 and h.get('Location')=='https://example.com/cloudlink-demo','Redirect failed')
    s,_,stats=request('/api/stats/'+code)
    require(s==200 and stats['clicks']==3,'Click counter failed')
    request('/r/'+code,'HEAD')
    require(request('/api/stats/'+code)[2]['clicks']==3,'HEAD changed counter')
    require(request('/api/links','POST',{'url':'javascript:alert(1)'})[0]==400,'Unsafe URL accepted')
    require(request('/r/xxxxxxxx')[0]==404,'Missing link must be 404')
    db=inspect(ids('db')[0])
    require(not db['HostConfig']['PortBindings'],'Database port is published')
    require('cloudlink_edge' not in db['NetworkSettings']['Networks'],'DB joined public edge network')
    print('PASS: create, redirect, exact counter, HEAD, validation, 404, database isolation')
    return code

def benchmark(n, concurrency, label, path='/api/instance'):
    # Safe no-write GET by default. Redirect workload is optional, with counters.
    def one(_):
        start=time.perf_counter()
        try:
            status,headers,body=request(path)
            good = status==200 if path=='/api/instance' else status==302
            return (time.perf_counter()-start)*1000,good,headers.get('X-Instance-ID','unknown'),str(status)
        except Exception as error:
            return (time.perf_counter()-start)*1000,False,'unavailable',type(error).__name__
    for _ in range(10): one(None)
    start=time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:
        rows=list(pool.map(one,range(n)))
    elapsed=time.perf_counter()-start
    lat=sorted(r[0] for r in rows)
    result={'label':label,'workload':path,'requests':n,'concurrency':concurrency,
        'seconds':round(elapsed,3),'throughput_rps':round(n/elapsed,2),
        'p95_ms':round(lat[math.ceil(.95*n)-1],2),
        'errors':sum(not r[1] for r in rows),'error_rate':sum(not r[1] for r in rows)/n,
        'instances':dict(collections.Counter(r[2] for r in rows)),
        'statuses':dict(collections.Counter(r[3] for r in rows))}
    # label is sanitized: filenames cannot escape results/.
    filename=''.join(c for c in label if c.isalnum() or c in '-_') or 'benchmark'
    out=ROOT/'results'/(filename+'.json'); out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2));return result

def compare(n, concurrency):
    all_results=[]
    for replicas in (1,3):
        scale(replicas)
        for trial in range(1,4):
            all_results.append(benchmark(n,concurrency,f'replicas-{replicas}-trial-{trial}'))
    (ROOT/'results/comparison.json').write_text(json.dumps(all_results,indent=2)+'\n')
    print('Three trials per replica count saved. The client, Nginx or database may limit speedup.')

def failure(n, concurrency):
    scale(3); victim=ids('link_api')[-1]
    try:
        run('docker','stop',victim)
        print('Intentionally stopped:',victim[:12],'. No proxy reload before measurement.')
        result=benchmark(n,concurrency,'one-replica-stopped')
        require(result['errors']==0,'Continuity test recorded errors. Inspect results and proxy logs.')
    finally:
        run('docker','start',victim)
        dc('up','-d','--wait','--scale','link_api=3','link_api')
        refresh_proxy()
    print('Victim explicitly restarted. docker stop does not demonstrate automatic restart.')

def persistence():
    code=smoke(); before=request('/api/stats/'+code)[2]
    dc('down')  # Intentionally omit -v. Keep all named volume data.
    up(3)
    after=request('/api/stats/'+code)[2]
    require(after.get('url')==before['url'] and after.get('clicks')==before['clicks'], 'Persistence failed')
    print('PASS: link and clicks survived container removal and recreation')

def doctor():
    require(shutil.which('docker'), 'Install and open Docker Desktop first: https://docs.docker.com/desktop/setup/install/mac-install/')
    run('docker','info',capture=True);dc('version');init();dc('config','--quiet')
    print('Docker is reachable and Compose configuration parses.')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['init','doctor','up','scale','instances','smoke','bench','compare','failure','persistence','status','down'])
    parser.add_argument('--replicas',type=int,choices=range(1,7),default=3)
    parser.add_argument('--requests',type=int,default=600)
    parser.add_argument('--concurrency',type=int,default=20)
    parser.add_argument('--label',default='manual')
    parser.add_argument('--path',default='/api/instance', help='Safe /api/instance or /r/CODE (counts clicks)')
    args=parser.parse_args()
    require(1<=args.requests<=100000 and 1<=args.concurrency<=200,'Use positive bounded request and concurrency counts')
    if args.command=='init':init()
    elif args.command=='doctor':doctor()
    elif args.command=='up':up(args.replicas)
    elif args.command=='scale':scale(args.replicas)
    elif args.command=='instances':distribution()
    elif args.command=='smoke':smoke()
    elif args.command=='bench':
        require(args.path=='/api/instance' or args.path.startswith('/r/'),'Only instance or redirect benchmarks are supported')
        benchmark(args.requests,args.concurrency,args.label,args.path)
    elif args.command=='compare':compare(args.requests,args.concurrency)
    elif args.command=='failure':failure(args.requests,args.concurrency)
    elif args.command=='persistence':persistence()
    elif args.command=='status':dc('ps')
    elif args.command=='down':dc('down')
if __name__=='__main__':
    try: main()
    except (RuntimeError, subprocess.CalledProcessError, FileNotFoundError, urllib.error.URLError) as error:
        print('ERROR:',str(error),file=sys.stderr);sys.exit(1)
