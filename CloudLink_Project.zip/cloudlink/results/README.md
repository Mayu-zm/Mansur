# Measured results
No Docker benchmark results are included in the prepared package.
Run `python3 scripts/manage.py compare` and `python3 scripts/manage.py failure` on your Mac.
The commands write actual JSON measurements into this directory.
The benchmark defaults to the lightweight instance endpoint. It demonstrates routing and safe-read continuity, not full redirect/database throughput.
To measure redirects, use `bench --path /r/ACTUAL_CODE --label redirects-1` and repeat at 3 replicas with identical request and concurrency counts. Redirect requests increment click counters. Do not follow external destinations during load tests.
