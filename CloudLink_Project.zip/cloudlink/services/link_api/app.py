import re
import secrets
from urllib.parse import urlsplit
from flask import Flask, jsonify, request, redirect
from common.store import Store
from common.http import configure, INSTANCE

CODE = re.compile(r"^[A-Za-z0-9_-]{8}$")

def valid_url(value):
    if not isinstance(value, str) or not 1 <= len(value) <= 2048:
        return False
    if any(c.isspace() or ord(c) < 32 or ord(c) == 127 for c in value) or "\\" in value:
        return False
    try:
        parts = urlsplit(value)
        port = parts.port
        return (parts.scheme.lower() in ("http", "https") and bool(parts.hostname)
            and parts.username is None and parts.password is None and (port is None or 1 <= port <= 65535))
    except ValueError:
        return False

def create_app(store=None):
    app = Flask(__name__)
    store = store or Store()
    configure(app, store)

    @app.get("/api/instance")
    def instance():
        return jsonify(service="link_api", instance=INSTANCE)

    @app.post("/api/links")
    def create_link():
        data = request.get_json(silent=True)
        if not isinstance(data, dict) or not valid_url(data.get("url")):
            return jsonify(error="Provide a valid HTTP or HTTPS URL without credentials or spaces"), 400
        for _ in range(5):
            code = secrets.token_urlsafe(6)
            row = store.create(code, data["url"])
            if row:
                return jsonify(code=code, url=row["url"], short_path="/r/" + code, instance=INSTANCE), 201
        return jsonify(error="Please try again"), 503

    @app.route("/r/<code>", methods=["GET", "HEAD"])
    def follow_link(code):
        if not CODE.fullmatch(code):
            return jsonify(error="Link not found"), 404
        # HEAD must not count as a click. UPDATE commits before returning the redirect.
        row = store.get(code) if request.method == "HEAD" else store.visit(code)
        if not row:
            return jsonify(error="Link not found"), 404
        return redirect(row["url"], code=302)

    return app

app = create_app()
