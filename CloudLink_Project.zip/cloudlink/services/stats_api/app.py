from flask import Flask, jsonify
from common.http import configure, INSTANCE
from common.store import Store

def create_app(store=None):
    app = Flask(__name__)
    store = store or Store()
    configure(app, store)

    @app.get("/api/stats")
    def stats():
        return jsonify(links=store.list_links(), instance=INSTANCE)

    @app.get("/api/stats/<code>")
    def detail(code):
        row = store.get(code)
        if row is None:
            return jsonify(error="Link not found"), 404
        return jsonify(row)

    return app

app = create_app()
