import socket
import psycopg
from flask import jsonify
from werkzeug.exceptions import HTTPException

INSTANCE = socket.gethostname()

def configure(app, store):
    app.config["MAX_CONTENT_LENGTH"] = 8192

    @app.after_request
    def headers(response):
        response.headers["X-Instance-ID"] = INSTANCE
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.get("/healthz")
    def health():
        return jsonify(status="alive", instance=INSTANCE)

    @app.get("/readyz")
    def ready():
        store.ready()
        return jsonify(status="ready", instance=INSTANCE)

    @app.errorhandler(psycopg.Error)
    def database_error(error):
        app.logger.error("database request failed: %s", type(error).__name__)
        return jsonify(error="Database temporarily unavailable"), 503

    @app.errorhandler(HTTPException)
    def http_error(error):
        return jsonify(error=error.description), error.code
