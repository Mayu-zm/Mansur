import os
import psycopg
from psycopg.rows import dict_row

class Store:
    def connect(self):
        return psycopg.connect(host=os.getenv("DB_HOST", "db"),
            dbname=os.environ["POSTGRES_DB"], user=os.environ["POSTGRES_USER"],
            password=os.environ["POSTGRES_PASSWORD"], connect_timeout=3,
            options="-c statement_timeout=5000", row_factory=dict_row)

    def ready(self):
        with self.connect() as conn:
            conn.execute("SELECT 1 FROM links LIMIT 1")

    def create(self, code, url):
        with self.connect() as conn:
            row = conn.execute("INSERT INTO links (code, url) VALUES (%s, %s) "
                "ON CONFLICT (code) DO NOTHING RETURNING code, url, clicks",
                (code, url)).fetchone()
        return row

    def visit(self, code):
        with self.connect() as conn:
            return conn.execute("UPDATE links SET clicks = clicks + 1 WHERE code = %s "
                "RETURNING url, clicks", (code,)).fetchone()

    def list_links(self):
        with self.connect() as conn:
            return conn.execute("SELECT code, url, clicks, created_at FROM links "
                "ORDER BY created_at DESC LIMIT 100").fetchall()

    def get(self, code):
        with self.connect() as conn:
            return conn.execute("SELECT code, url, clicks, created_at FROM links "
                "WHERE code = %s", (code,)).fetchone()
