# CloudLink speaking and live demonstration
Use these lines after running and understanding the relevant feature. Proposed responsibilities come from the proposal. Replace any contribution statement with what each person actually did. Do not read claims about unobserved results.

## Yelnur 0 to 2 minutes
Good morning. Our group is Cloud Builders. Our project is CloudLink, a URL shortener with click statistics. A user enters a long URL, receives a short link and can see how many redirect requests it receives.

Our main goal is to demonstrate a container-based system. We use Docker Compose to run Nginx, two Python services and PostgreSQL. Nginx is the entry point. It serves our interface and forwards API requests. The Link API creates links and redirects users. The Statistics API reads click counts. The services keep shared data in PostgreSQL, so an application container does not need local user data.

This is a local prototype on Docker Desktop. It demonstrates container isolation, horizontal scaling, load balancing and persistent storage. It is not a deployment on a public cloud provider.

[Show slide 1, then run: python3 scripts/manage.py status]

## Akerke 2 to 4 minutes
I will demonstrate the link service and the interface. I enter an HTTPS destination and click Create short link. The API checks the URL and creates a random code. If a code already exists, it tries again.

[Create https://example.com. Open the generated short link once. Return and refresh statistics.]

When I open the short link, the service updates the database counter and returns an HTTP 302 redirect. The update uses one SQL statement, so concurrent requests do not overwrite each other's increments. The count represents redirect requests, not unique visitors. A HEAD request does not increase the count.

We validate the URL scheme, use SQL parameters and insert dashboard text safely. The Python containers run as a non-root user. The database has no published host port. A public version would also need authentication, rate limiting and HTTPS.

## Yelnur 4 to 6 minutes
Now I will demonstrate horizontal scaling. With one replica, all instance requests reach the same container.

[Run: python3 scripts/manage.py scale --replicas 1]
[Run: python3 scripts/manage.py instances]

I scale the Link API to three replicas. Our script refreshes the Nginx upstream configuration and reloads it. Repeated requests now show different container IDs.

[Run: python3 scripts/manage.py scale --replicas 3]
[Run: python3 scripts/manage.py instances]

This demonstrates request distribution. More replicas do not guarantee three times more throughput because all containers share one host, proxy and database. Our benchmark records actual throughput, p95 latency and errors. We compare the same workload and concurrency across three trials. The default benchmark is a safe instance request, so it measures routing rather than the full redirect workload.

## Mansur 6 to 9 minutes
I will show failure handling and persistence. We stop one of the three Link API containers. Nginx detects failed upstream connections and can retry safe instance requests through the remaining replicas.

[Run: python3 scripts/manage.py failure --requests 120 --concurrency 10]

The command prints measured errors and instance IDs. This demonstration restores the stopped container explicitly. A manual stop is different from an unexpected process exit. Our restart policy handles exits, but Docker Compose does not restart a container simply because it becomes unhealthy.

We disable proxy retries for link creation and counted redirects to reduce repeated writes. These requests may briefly fail during an outage. We do not claim exactly-once click tracking.

Our database stores data in a named Docker volume. We can remove the containers and recreate them while keeping the links and counters.

[Run: python3 scripts/manage.py persistence]

The check creates a fresh link, records three clicks, recreates the stack and checks the same values. We keep the volume by using docker compose down without the volume deletion option.

## Closing 9 to 10 minutes
Our project demonstrates a complete local container deployment with separate services and persistent data. Its main limitations are the single host, shared database and single proxy. Future work could add public-cloud deployment, TLS, authentication, monitoring and database backups. Thank you. We are ready for questions.

## Results sentence after actual measurements
For the instance endpoint, at [C] concurrent requests, the median throughput across three trials was [A] requests per second with one replica and [B] with three replicas. The p95 latency values were [X] and [Y] milliseconds. We recorded [E1] and [E3] errors. This result measures this laptop and this workload only.

If no benchmark has run, say: We have prepared the benchmark procedure, but we do not have measured performance results yet.
