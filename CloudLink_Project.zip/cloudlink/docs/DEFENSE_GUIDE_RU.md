# CloudLink подготовка и защита

## Что вы выбрали
Команда Cloud Builders. Проект CloudLink — сокращатель ссылок со статистикой переходов. Участники: Tlektes Yelnur 202699544, Anefiyayeva Akerke 202699542, Malik Mansur 202699543. Тема и роли взяты из вашей заявки. Тип — Docker & Microservices. Среда — Docker Desktop на macOS. AWS и Kubernetes для этой заявки не обязательны.

## Что требует преподаватель
Нужно уметь спроектировать, развернуть, эксплуатировать и объяснить систему. Показать только сайт или презентацию недостаточно. В руководстве 30 баллов: участие 5, техническое качество 10, защита 15. Оцениваются архитектура, облачные технологии, масштабируемость, надёжность, автоматизация, сеть, безопасность, хранение, документация и понимание кода.

В вашей реализации нужно показать создание короткой ссылки, HTTP 302, счётчик, независимые сервисы, Docker Compose, 1 и 3 реплики, разные instance IDs, измерения производительности, остановку одной реплики и сохранность БД после пересоздания контейнеров.

## Когда и как проходит защита
В подробном расписании Group 1, ID 2026-99544, указан 20 ноября 2026, 09:30-09:40. Следующие две строки группы — 09:40-09:50 и 09:50-10:00 — имеют пустые ID. Поэтому блок вашей группы вероятно 09:30-10:00, но Акерке и Мансур в этом файле по именам не назначены. Время местное, корейское. Общие слайды дают другие, менее подробные даты; окончательное время нужно сверить с преподавателем.

Подключение компьютера — до 2 минут. Презентация и демонстрация — 5-10 минут. Можно использовать 1-2 слайда или выступить без слайдов. Вопросы — до 5 минут на студента: один от преподавателя и один от одногруппника. В листе оценок также есть колонка Q-to-Others, поэтому подготовьте осмысленный вопрос другой команде. Не воспринимайте баллы этой таблицы как гарантированную формулу итоговой оценки: в руководстве критерии гибкие.

В общих слайдах указан запрет обновлений GitHub после 18 ноября 2026, 23:55. Это срок сдачи кода, отдельный от времени защиты. Этот пакет подготовлен позже. Не меняйте даты коммитов и не называйте новый код ранее сданным. Уточните возможность поздней сдачи. Планируемый GitHub из заявки ещё не был создан или проверен в рамках этой работы.

## Что уже подготовлено и что ещё проверить
Подготовлены исходники обоих сервисов, интерфейс, SQL, Dockerfiles, Compose, Nginx, команды управления, тесты, README, два слайда, сценарий выступления и ответы на вопросы. В среде подготовки прошли 27 unit/API/SQL contract тестов. Они используют подмену хранилища и не подтверждают работу PostgreSQL. Docker здесь отсутствовал, поэтому полный стек, сборка образов, масштабирование и сохранность volume ещё требуют проверки на вашем Mac. Готовых измерений нагрузки нет.

## Запуск на Mac
1. Установи Docker Desktop с официального сайта Docker и открой приложение. Дождись запуска engine. Проверь python3 --version. Если Python отсутствует, установи Python 3.
2. Распакуй ZIP. Открой Terminal, введи cd с пробелом, перетащи папку cloudlink в окно терминала и нажми Enter. Внутри должны быть compose.yaml и scripts.
3. Выполни python3 scripts/manage.py doctor. Команда создаст .env с паролем, проверит Docker и синтаксис Compose. Не отправляй .env на GitHub.
4. Выполни python3 scripts/manage.py up. Первый запуск скачивает образы и зависимости и требует интернет. Дождись конца команды. Открой http://localhost:8080.
5. Выполни python3 scripts/manage.py smoke. Ожидается PASS. Если команда падает, прочитай ошибку и docker compose logs --tail 80. До исправления не считай стек готовым к защите.
6. Выполни python3 scripts/manage.py compare. Сохрани реальные JSON из results. Сделай скриншоты интерфейса, docker compose ps, распределения по репликам и итогов проверок. На слайдах нет выдуманных показателей.
7. Прогони failure и persistence из README. После репетиции оставь 3 реплики работающими. Заряди Mac, возьми адаптер для проектора и открой заранее терминал, сайт и два слайда. Не рассчитывай скачивать Docker-образы за 2 минуты подключения.

## Что делают файлы
compose.yaml описывает сервисы, сети, volume и readiness. Dockerfile создаёт образ каждого Python-сервиса. Gunicorn запускает Flask. services/common/store.py содержит SQL с параметрами. Link API проверяет адрес, создаёт код и атомарно увеличивает счётчик. Statistics API читает БД. nginx.conf задаёт маршруты и поведение повторных запросов. manage.py управляет стеком и обновляет IP реплик в конфигурации Nginx. web содержит интерфейс. results содержит только реально полученные измерения после твоего запуска.

## Репетиция по ролям
По заявке Yelnur отвечает за инфраструктуру, деплой, балансировку и масштабирование; Akerke — за Link API, интерфейс и валидацию; Mansur — за Statistics API, БД и тестирование. Эти роли — план работы. Каждый должен лично запустить и изучить свою часть и честно объяснять фактический вклад. Готовый текст на английском находится в SPEAKING_EN.md. Каждый должен понимать всю архитектуру, а не только свой текст.

Сценарий: Yelnur показывает архитектуру и контейнеры 0-2 минуты. Akerke создаёт ссылку и показывает переход и счётчик 2-4 минуты. Yelnur показывает 1 и 3 реплики и разные instance IDs 4-6 минут. Mansur показывает отказ и volume 6-9 минут. До 10-й минуты — ограничения и завершение. Если пересоздание занимает долго, объясняйте команды и показывайте заранее сохранённые результаты как запись предыдущего прогона, а не выдавайте их за живой результат. Основная функциональность всё равно должна работать вживую.

## Частые проблемы
Docker not found — установи Docker Desktop. Cannot connect to daemon — открой Docker Desktop и дождись engine. Port allocated — поменяй APP_PORT в .env и выполни up. 502 после пересоздания приложений — снова up либо scale, чтобы обновить upstreams. Database password authentication failed — пароль .env отличается от пароля в существующем volume; изменение .env не меняет роль PostgreSQL. Не удаляй volume ради исправления без сохранения нужных данных. Один instance ID после scale 3 — проверь status и instances; не делай вывод по единственному клику в браузере. Нет ускорения при трёх репликах — это допустимый результат; ищи ограничение на клиенте, Nginx, CPU или БД и сообщай реальные цифры.

## Вопросы и ответы для защиты
1. What problem does your project solve? — It creates short links and reports redirect request counts.
2. Why is it a cloud implementation project? — It demonstrates containerized compute, isolated networks, persistent storage, repeatable deployment, horizontal scaling and failure handling on a local host.
3. Is this already a public cloud deployment? — No. It is a Docker Desktop prototype. We could deploy it on a VM later, with security and operational changes.
4. Is it IaaS, PaaS or SaaS? — The end-user URL-shortening function resembles SaaS. Our implementation demonstrates application deployment; we do not provide an IaaS or PaaS platform.
5. What is an image? — An image is a packaged, layered filesystem and configuration used to create containers.
6. What is a container? — An isolated process environment created from an image. A container can contain multiple processes and shares the kernel supplied by its runtime host. Docker Desktop on macOS uses a Linux VM.
7. Docker versus a VM? — Containers share a host kernel. A VM has its own guest kernel. Docker Desktop runs Linux containers inside a VM on a Mac.
8. What does a Dockerfile do? — It defines how to build an image, install dependencies, copy application code and start Gunicorn.
9. Why two services? — Link creation and redirection can scale separately from statistics reads. They are independently deployable, although sharing a database couples them.
10. How do containers communicate? — By their Docker network addresses. Compose DNS names support initial startup; our script writes current replica IPs into Nginx after scaling.
11. What is stateless here? — The application containers keep durable link data in PostgreSQL rather than their local writable layer.
12. How does scaling work? — Compose changes the Link API replica count. The controller regenerates Nginx upstreams and reloads Nginx. This is manual scaling with scripted operations.
13. Does scaling guarantee a speedup? — No. Shared host resources, the load client, proxy or database may limit throughput. We measure identical workloads and report actual results.
14. How do you prove balancing? — Repeated /api/instance requests return different X-Instance-ID values. Logs and distribution counts provide evidence.
15. What does p95 mean? — 95 percent of measured request durations are at or below that latency. The command includes failed requests in the latency sample and reports errors separately.
16. What does the default load test measure? — Safe instance requests, mainly routing and service response. Full redirect throughput requires the optional /r/CODE workload, which updates the database.
17. What happens if one replica stops? — Safe instance requests can retry another replica. Counted redirects and creates disable proxy replay, so they can briefly fail. We explicitly restore the stopped container.
18. Does Docker restart an unhealthy container? — Not from the restart policy alone. Restart policies apply when the container exits. Intentional stop suppresses automatic restart until it is started again.
19. What if PostgreSQL stops? — Readiness fails and database-dependent endpoints return 503. Another Link API replica cannot repair a shared database outage.
20. What if Nginx or the laptop fails? — The service becomes unavailable. We have a single proxy and host, so we do not claim high availability for the entire system.
21. How is data retained? — A named volume keeps PostgreSQL data outside the container lifecycle. Removing containers without deleting the volume preserves links.
22. How do you avoid lost increments? — UPDATE links SET clicks = clicks + 1 executes atomically in PostgreSQL and commits before returning the redirect. It is not exactly-once tracking: a lost response or user retry can still affect semantics.
23. Which security controls exist? — SQL parameters, URL checks, request size limits, non-root Python processes, private DB network, no DB host port, loopback binding, safe text rendering and credentials outside git.
24. Does the server fetch user URLs? — No. It stores them and sends a redirect. The public version still needs protections against phishing and abuse.
25. What would you improve? — Add authentication, rate limits, TLS, migrations, backup and restore tests, monitoring and database/proxy redundancy. Moving to Kubernetes would require health probes and a proper ingress/service design.
26. How do you know it works? — Unit tests cover API rules; live smoke tests cover the real stack; distribution, failure and persistence commands test operational scenarios. We distinguish tests actually run from prepared checks.
27. What did each person contribute? — Explain actual reviewed files, commands run and changes made. Do not present the proposal's role allocation as completed contribution evidence.

## Вопросы другой команде
How did you verify that your service still works when one component fails?
Where is your persistent data stored, and what happens when you recreate a container?
What limits the scalability of your current implementation?

## Источники
Ваша заявка cloud project guidance Yelnur's team.docx; 01 Projects Guidance.pptx; 03a Demo Schedules (2026-02 cdi).docx; 03b Demo Questions (2026-02 cdi) Sample.txt; шаблон 02a Project Teams and Evaluations (template).docx. Технические ссылки приведены в README. Даты и требования выше взяты из этих файлов, а не из внешнего расписания университета.
