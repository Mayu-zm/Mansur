import pytest
import psycopg
from link_api.app import create_app, valid_url
from stats_api.app import create_app as stats_app

class MemoryStore:
    def __init__(self): self.rows={}
    def ready(self): pass
    def create(self, code, url):
        if code in self.rows:return None
        self.rows[code] = dict(code=code, url=url, clicks=0)
        return self.rows[code].copy()
    def visit(self, code):
        if code not in self.rows:return None
        self.rows[code]['clicks']+=1
        return self.rows[code].copy()
    def get(self,code):return self.rows.get(code)
    def list_links(self):return list(self.rows.values())

@pytest.mark.parametrize('url',['https://example.com','http://example.com/a?x=1','https://example.com:443/path'])
def test_valid(url):assert valid_url(url)

@pytest.mark.parametrize('url',[None,5,{},'', 'ftp://example.com','javascript:alert(1)','https://a.com/\r\nX:1','https://u:p@example.com','https://a.com:99999','https://[bad','https://a.com/a b','https://a.com/\\evil'])
def test_invalid(url):assert not valid_url(url)

def test_flow_and_head():
    store=MemoryStore();link=create_app(store).test_client();stats=stats_app(store).test_client()
    response=link.post('/api/links',json={'url':'https://example.com/test'})
    assert response.status_code==201
    code=response.json['code']; assert len(code)==8
    for _ in range(3):
        result=link.get('/r/'+code)
        assert result.status_code==302 and result.headers['Location']=='https://example.com/test'
    assert link.head('/r/'+code).status_code==302
    assert stats.get('/api/stats/'+code).json['clicks']==3
    assert len(stats.get('/api/stats').json['links'])==1
    assert response.headers['X-Instance-ID']
    assert response.headers['Cache-Control']=='no-store'

@pytest.mark.parametrize('body',[{},[],None,{'url':'file:///etc/passwd'},{'url':5}])
def test_bad_payload(body):
    assert create_app(MemoryStore()).test_client().post('/api/links',json=body).status_code==400

def test_missing_and_health():
    client=create_app(MemoryStore()).test_client()
    assert client.get('/r/xxxxxxxx').status_code==404
    assert client.get('/r/bad-code-too-long').status_code==404
    assert client.get('/readyz').status_code==200
    assert client.get('/healthz').status_code==200
    assert stats_app(MemoryStore()).test_client().get('/api/stats/xxxxxxxx').status_code==404

def test_database_outage():
    class Broken(MemoryStore):
        def ready(self):raise psycopg.OperationalError('secret credential should not leak')
    client=create_app(Broken()).test_client()
    response=client.get('/readyz')
    assert response.status_code==503 and 'secret' not in response.get_data(as_text=True)
    assert client.get('/healthz').status_code==200

def test_collision_retry(monkeypatch):
    store=MemoryStore();store.create('existing','https://example.com')
    codes=iter(['existing','newcode1']); monkeypatch.setattr('link_api.app.secrets.token_urlsafe',lambda n:next(codes))
    result=create_app(store).test_client().post('/api/links',json={'url':'https://example.org'})
    assert result.status_code==201 and result.json['code']=='newcode1'

def test_collision_limit(monkeypatch):
    store=MemoryStore();store.create('existing','https://example.com')
    monkeypatch.setattr('link_api.app.secrets.token_urlsafe',lambda n:'existing')
    assert create_app(store).test_client().post('/api/links',json={'url':'https://example.org'}).status_code==503

def test_large_request():
    result=create_app(MemoryStore()).test_client().post('/api/links',data='x'*9000,content_type='application/json')
    assert result.status_code==413
