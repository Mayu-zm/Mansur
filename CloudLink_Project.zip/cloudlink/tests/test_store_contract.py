from common.store import Store

class Connection:
    def __init__(self):self.calls=[]
    def __enter__(self):return self
    def __exit__(self,*args):return False
    def execute(self,sql,params=()):self.calls.append((sql,params));return self
    def fetchone(self):return {'url':'https://example.com','clicks':1}
    def fetchall(self):return []

def test_sql_parameters_and_atomic_increment(monkeypatch):
    conn=Connection();store=Store();monkeypatch.setattr(store,'connect',lambda:conn)
    hostile="x'; DROP TABLE links; --"
    store.create('abcdefgh',hostile)
    sql,params=conn.calls[-1]
    assert hostile not in sql and params==('abcdefgh',hostile)
    store.visit('abcdefgh')
    sql,params=conn.calls[-1]
    assert 'clicks = clicks + 1' in sql and 'RETURNING' in sql and params==('abcdefgh',)
