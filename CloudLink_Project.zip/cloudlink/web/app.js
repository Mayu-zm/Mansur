const $ = id => document.getElementById(id);
async function api(path, options) {
  const response = await fetch(path, options);
  const body = await response.json().catch(() => ({error: 'Service temporarily unavailable'}));
  if (!response.ok) throw new Error(body.error || 'Request failed');
  return body;
}
function message(text) { $('message').textContent = text; }
async function probe() {
  try { const r = await api('/api/instance'); $('instance').textContent = r.instance; }
  catch(e) { $('instance').textContent = e.message; }
}
async function refresh() {
  try {
    const result = await api('/api/stats');
    $('links').replaceChildren();
    for (const link of result.links) {
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      const a = document.createElement('a');
      a.href = '/r/' + encodeURIComponent(link.code); a.textContent = link.code;
      a.target = '_blank'; a.rel = 'noopener noreferrer'; td.append(a); tr.append(td);
      for (const text of [link.url, link.clicks]) { const cell = document.createElement('td'); cell.textContent = text; tr.append(cell); }
      $('links').append(tr);
    }
    if (!result.links.length) { const tr = document.createElement('tr'); const td = document.createElement('td'); td.colSpan=3; td.textContent='No links yet. Create your first short link above.'; tr.append(td); $('links').append(tr); }
    $('connection').textContent = 'Statistics service online';
  } catch(e) { $('connection').textContent = 'Statistics service unavailable'; message(e.message); }
}
$('shorten').addEventListener('submit', async event => {
  event.preventDefault(); $('create').disabled = true;
  try {
    const r = await api('/api/links', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({url:$('url').value}) });
    const short = location.origin + r.short_path;
    $('short-link').href=short; $('short-link').textContent=short; $('new-link').hidden=false;
    $('instance').textContent=r.instance; message('Link created. Open it to record a click.'); await refresh();
  } catch(e) { message(e.message); } finally { $('create').disabled=false; }
});
$('copy').addEventListener('click', async () => { try { await navigator.clipboard.writeText($('short-link').href); message('Copied to clipboard.'); } catch { message('Select the short link and copy it manually.'); } });
$('refresh').addEventListener('click', refresh); $('probe').addEventListener('click', probe);
refresh(); probe(); setInterval(refresh, 5000);
